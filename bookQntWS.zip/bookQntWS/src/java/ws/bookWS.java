/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author nick
 */
@WebService(serviceName = "bookWS")
public class bookWS {

    /**
     * This is a sample web service operation
     */
    BookManager bm  = new BookManager();    
   
    @WebMethod(operationName = "allBooks")
    public List<BookDB> books(){
        return bm.getallBooks();
    }
    @WebMethod(operationName = "findByIsbn")
    public BookDB isbns(@WebParam(name = "isbninput") String isbninput){
        
        return bm.getQuantity(isbninput);
    }
    @WebMethod(operationName = "updateQuantity")
    public Boolean update(@WebParam(name = "isbn_input") String isbn_input, @WebParam(name = "quantity_input") Integer quantity_input){
        BookDB b  = new BookDB();
        b.setIsbn(isbn_input);
        b.setQuantity(quantity_input);
        Boolean result = bm.updatequantity(b);
        System.out.println("Result "+result);
        return result;
    }    
   
}
