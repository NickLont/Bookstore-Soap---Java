/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nick
 */
public class BookManager {
    private Connection connection;
    public BookManager(){
        connection = Database.getConnection();
    }
    
    public List<BookDB> getallBooks(){
        List<BookDB> books = new ArrayList<BookDB>();
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from bookDB order by isbn limit 50");
            while (rs.next()) {
                BookDB user = new BookDB();
                user.setIsbn(rs.getString("Isbn"));
                user.setQuantity(rs.getInt("quantity"));
                books.add(user);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }
    
    public BookDB getQuantity(String isbn_input){
        BookDB book = new BookDB();
        String query = "select * from bookDB where isbn="+isbn_input;
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            while (rs.next())
            {
               book.setIsbn(rs.getString("isbn"));
               book.setQuantity(rs.getInt("quantity"));               
            }
            
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return book;
    }
    
    public Boolean updatequantity(BookDB book){
        Boolean b= false;
        try {
            System.out.println("update db start");
            String query = "update bookDB set quantity=? where isbn=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, book.getQuantity());
            preparedStatement.setString(2, book.getIsbn());
            preparedStatement.executeUpdate();
            System.out.println("update db finish");
            b=true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return b;
    }
    
//    public boolean createActor(Actor actor){
//        Boolean b=false;
//              
//        try {
//            System.out.println("add user start");
//            PreparedStatement preparedStatement = connection.prepareStatement("insert into actor(first_name, last_name) values (?, ?)");
//            // Parameters start with 1
//            preparedStatement.setString(1, actor.getFirstName());
//            preparedStatement.setString(2, actor.getLastName());
//            preparedStatement.executeUpdate();
//             System.out.println("add user end");
//             b=true;
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        
//        return b;
//    }
}
